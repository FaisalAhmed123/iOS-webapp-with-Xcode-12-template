//
//  Darussalam_Masjid_iOS_appApp.swift
//  Darussalam Masjid iOS app
//
//  Created by Faisal Ahmed on 10/01/2021.
//

import SwiftUI

@main
struct Darussalam_Masjid_iOS_appApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
